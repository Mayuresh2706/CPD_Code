//Numpy array shape [4]
//Min -0.062500000000
//Max 0.023437500000
//Number of zeros 1

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
bias15_t b15[4];
#else
bias15_t b15[4] = {-0.0078125, 0.0000000, 0.0234375, -0.0625000};
#endif

#endif
