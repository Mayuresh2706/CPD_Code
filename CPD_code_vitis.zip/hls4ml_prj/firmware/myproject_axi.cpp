#include "myproject_axi.h"

void myproject_axi(hls::stream<input_axi_t> &in, hls::stream<output_axi_t> &out) {
    #pragma HLS INTERFACE axis port=in
    #pragma HLS INTERFACE axis port=out
    #pragma HLS INTERFACE ap_ctrl_none port=return
    #pragma HLS DATAFLOW

    hls::stream<input_t> in_local("input_1");
    hls::stream<result_t> out_local("output_1");

    #pragma HLS STREAM variable=in_local depth=1024
    #pragma HLS STREAM variable=out_local depth=1

    // Read 1024 packed 32-bit words from DMA (1 word = 4 channels of 8-bit)
    for(unsigned i = 0; i < N_IN / input_t::size; ++i) {
        input_axi_t axi_in = in.read();
        ap_uint<32> packed_data = axi_in.data;
        
        input_t ctype;
        #pragma HLS DATA_PACK variable=ctype
        
        // Unpack the 32-bit word into 4 channels of ap_fixed<8,4>
        ctype[0] = typename input_t::value_type(packed_data(7, 0));
        ctype[1] = typename input_t::value_type(packed_data(15, 8));
        ctype[2] = typename input_t::value_type(packed_data(23, 16));
        ctype[3] = typename input_t::value_type(packed_data(31, 24));
        
        in_local.write(ctype);
    }

    myproject(in_local, out_local);

    // Read 1 result (4 classes of ap_fixed<8,4> = 32 bits = 1 word)
    for(unsigned i = 0; i < N_OUT / result_t::size; ++i) {
        result_t ctype = out_local.read();
        
        // Pack all 4 outputs into a single 32-bit word for the DMA
        // (class 0-2 are real predictions, class 3 is the dummy padding class)
        ap_uint<32> packed_out = 0;
        packed_out(7, 0)   = ctype[0].range(7, 0);
        packed_out(15, 8)  = ctype[1].range(7, 0);
        packed_out(23, 16) = ctype[2].range(7, 0);
        packed_out(31, 24) = ctype[3].range(7, 0);  // dummy class (ignore on host)
        
        output_axi_t axi_out;
        axi_out.data = packed_out;
        axi_out.keep = -1;
        axi_out.strb = -1;
        axi_out.user = 0;
        axi_out.id   = 0;
        axi_out.dest = 0;
        axi_out.last = (i == (N_OUT / result_t::size) - 1) ? 1 : 0;
        
        out.write(axi_out);
    }
}
