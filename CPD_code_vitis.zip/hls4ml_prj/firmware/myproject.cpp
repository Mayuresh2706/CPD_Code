#include <iostream>

#include "myproject.h"
#include "parameters.h"

void myproject(
    hls::stream<input_t> &conv1_input,
    hls::stream<result_t> &layer17_out
) {

    #pragma HLS INTERFACE axis port=conv1_input,layer17_out 
    #pragma HLS DATAFLOW 

#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        nnet::load_weights_from_txt<weight2_t, 288>(w2, "w2.txt");
        nnet::load_weights_from_txt<bias2_t, 8>(b2, "b2.txt");
        nnet::load_weights_from_txt<weight5_t, 1152>(w5, "w5.txt");
        nnet::load_weights_from_txt<bias5_t, 16>(b5, "b5.txt");
        nnet::load_weights_from_txt<weight8_t, 2304>(w8, "w8.txt");
        nnet::load_weights_from_txt<bias8_t, 16>(b8, "b8.txt");
        nnet::load_weights_from_txt<weight12_t, 8192>(w12, "w12.txt");
        nnet::load_weights_from_txt<bias12_t, 32>(b12, "b12.txt");
        nnet::load_weights_from_txt<weight15_t, 128>(w15, "w15.txt");
        nnet::load_weights_from_txt<bias15_t, 4>(b15, "b15.txt");
        loaded_weights = true;
    }
#endif

    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************


    hls::stream<layer18_t> layer18_out("layer18_out");
    #pragma HLS STREAM variable=layer18_out depth=1089
    nnet::zeropad2d_cl<input_t, layer18_t, config18>(conv1_input, layer18_out); // zp2d_conv1

    hls::stream<layer2_t> layer2_out("layer2_out");
    #pragma HLS STREAM variable=layer2_out depth=256
    nnet::conv_2d_cl<layer18_t, layer2_t, config2>(layer18_out, layer2_out, w2, b2); // conv1

    hls::stream<layer19_t> layer19_out("layer19_out");
    #pragma HLS STREAM variable=layer19_out depth=289
    nnet::zeropad2d_cl<layer2_t, layer19_t, config19>(layer2_out, layer19_out); // zp2d_conv2

    hls::stream<layer5_t> layer5_out("layer5_out");
    #pragma HLS STREAM variable=layer5_out depth=64
    nnet::conv_2d_cl<layer19_t, layer5_t, config5>(layer19_out, layer5_out, w5, b5); // conv2

    hls::stream<layer20_t> layer20_out("layer20_out");
    #pragma HLS STREAM variable=layer20_out depth=81
    nnet::zeropad2d_cl<layer5_t, layer20_t, config20>(layer5_out, layer20_out); // zp2d_conv3

    hls::stream<layer8_t> layer8_out("layer8_out");
    #pragma HLS STREAM variable=layer8_out depth=16
    nnet::conv_2d_cl<layer20_t, layer8_t, config8>(layer20_out, layer8_out, w8, b8); // conv3

    auto& layer11_out = layer8_out;
    hls::stream<layer12_t> layer12_out("layer12_out");
    #pragma HLS STREAM variable=layer12_out depth=1
    nnet::dense<layer8_t, layer12_t, config12>(layer11_out, layer12_out, w12, b12); // dense1

    hls::stream<layer15_t> layer15_out("layer15_out");
    #pragma HLS STREAM variable=layer15_out depth=1
    nnet::dense<layer12_t, layer15_t, config15>(layer12_out, layer15_out, w15, b15); // output

    nnet::softmax<layer15_t, result_t, softmax_config17>(layer15_out, layer17_out); // softmax

}
