#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <cstddef>
#include <cstdio>

// hls-fpga-machine-learning insert numbers
#define N_INPUT_1_1 32
#define N_INPUT_2_1 32
#define N_INPUT_3_1 4
#define OUT_HEIGHT_18 33
#define OUT_WIDTH_18 33
#define N_CHAN_18 4
#define OUT_HEIGHT_2 16
#define OUT_WIDTH_2 16
#define N_FILT_2 8
#define OUT_HEIGHT_19 17
#define OUT_WIDTH_19 17
#define N_CHAN_19 8
#define OUT_HEIGHT_5 8
#define OUT_WIDTH_5 8
#define N_FILT_5 16
#define OUT_HEIGHT_20 9
#define OUT_WIDTH_20 9
#define N_CHAN_20 16
#define OUT_HEIGHT_8 4
#define OUT_WIDTH_8 4
#define N_FILT_8 16
#define N_SIZE_0_11 256
#define N_LAYER_12 32
#define N_LAYER_15 4
#define N_LAYER_15 4

// hls-fpga-machine-learning insert layer-precision
typedef nnet::array<ap_fixed<16,6>, 4*1> input_t;
typedef nnet::array<ap_fixed<16,6>, 4*1> layer18_t;
typedef ap_fixed<16,6> conv1_accum_t;
typedef nnet::array<ap_fixed<16,6>, 8*1> layer2_t;
typedef ap_fixed<8,1> weight2_t;
typedef ap_fixed<8,1> bias2_t;
typedef nnet::array<ap_fixed<16,6>, 8*1> layer19_t;
typedef ap_fixed<16,6> conv2_accum_t;
typedef nnet::array<ap_fixed<16,6>, 16*1> layer5_t;
typedef ap_fixed<8,1> weight5_t;
typedef ap_fixed<8,1> bias5_t;
typedef nnet::array<ap_fixed<16,6>, 16*1> layer20_t;
typedef ap_fixed<16,6> conv3_accum_t;
typedef nnet::array<ap_fixed<16,6>, 16*1> layer8_t;
typedef ap_fixed<8,1> weight8_t;
typedef ap_fixed<8,1> bias8_t;
typedef ap_fixed<16,6> dense1_accum_t;
typedef nnet::array<ap_fixed<16,6>, 32*1> layer12_t;
typedef ap_fixed<8,1> weight12_t;
typedef ap_fixed<8,1> bias12_t;
typedef ap_uint<1> layer12_index;
typedef ap_fixed<16,6> output_accum_t;
typedef nnet::array<ap_fixed<16,6>, 4*1> layer15_t;
typedef ap_fixed<8,1> weight15_t;
typedef ap_fixed<8,1> bias15_t;
typedef ap_uint<1> layer15_index;
typedef nnet::array<ap_fixed<16,6>, 4*1> result_t;
typedef ap_fixed<18,8> softmax_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT> softmax_exp_table_t;
typedef ap_fixed<18,8,AP_RND,AP_SAT> softmax_inv_table_t;

#endif
