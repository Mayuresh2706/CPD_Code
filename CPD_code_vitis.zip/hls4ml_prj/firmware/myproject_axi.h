#ifndef MYPROJECT_AXI_H_
#define MYPROJECT_AXI_H_

#include <iostream>
#include "myproject.h"
#include "ap_axi_sdata.h"

static const unsigned N_IN = 4096;
static const unsigned N_OUT = 4;

// By using ap_axiu<32,1,1,1>, Vitis HLS guarantees the TDATA bus is EXACTLY 32-bits wide.
// Both input (4 channels x 8b) and output (4 classes x 8b) are natively 32 bits.
typedef ap_axiu<32, 1, 1, 1> input_axi_t;
typedef ap_axiu<32, 1, 1, 1> output_axi_t;

void myproject_axi(hls::stream<input_axi_t> &in, hls::stream<output_axi_t> &out);

#endif
